﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMat0030482221010
{
    public partial class Form1 : Form
    {
        private int[] vetorA =  new int [10];
        private int[] vetorB = new int [10];
        private object tbVetorA;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnInfoVal_Click(object sender, EventArgs e)
        {
            string[] valoresA = tbVetorA.Text.Split(',');

            if (valoresA.Length != vetorA.Length)
            {
                MessageBox.Show($"O vetor A deve conter {vetorA.Length} números separados por vírgula.");
                return;
            }

            for (int i = 0; i < vetorA.Length; i++)
                if (!int.TryParse(valoresA[i], out vetorA[i]))
                {
                    MessageBox.Show($"O valor '{valoresA[i]}' no vetor A não é um número válido.");
                    return;
                }

            for (int i = 0; i < vetorA.Length; i++)
            {
                if (i % 2 == 0)
                {
                    vetorB[i] = vetorA[i] * 5;
                }
                else
                {
                    vetorB[i] = vetorA[i] + 5;
                }
            }
        }

        private void LstbxValores_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstbxValores.Items.Clear();

            for (int i = 0; i < vetorA.Length; i++);
            {
                lstbxValores.Items.Add($"A[(i)] = (vetorA[i]), B[(i)] = vetorB[i])");
            }

        }
    }
}
