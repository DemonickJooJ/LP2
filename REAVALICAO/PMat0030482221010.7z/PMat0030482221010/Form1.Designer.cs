﻿namespace PMat0030482221010
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstbxValores = new System.Windows.Forms.ListBox();
            this.btnInfoVal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstbxValores
            // 
            this.lstbxValores.FormattingEnabled = true;
            this.lstbxValores.Location = new System.Drawing.Point(326, 200);
            this.lstbxValores.Name = "lstbxValores";
            this.lstbxValores.Size = new System.Drawing.Size(341, 238);
            this.lstbxValores.TabIndex = 1;
            this.lstbxValores.SelectedIndexChanged += new System.EventHandler(this.LstbxValores_SelectedIndexChanged);
            // 
            // btnInfoVal
            // 
            this.btnInfoVal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfoVal.Location = new System.Drawing.Point(154, 200);
            this.btnInfoVal.Name = "btnInfoVal";
            this.btnInfoVal.Size = new System.Drawing.Size(75, 75);
            this.btnInfoVal.TabIndex = 2;
            this.btnInfoVal.Text = "Informar Valores";
            this.btnInfoVal.UseVisualStyleBackColor = true;
            this.btnInfoVal.Click += new System.EventHandler(this.BtnInfoVal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInfoVal);
            this.Controls.Add(this.lstbxValores);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstbxValores;
        private System.Windows.Forms.Button btnInfoVal;
    }
}

